/* Real estate page: interactive content.
   To change the wording of the panels, edit the data blocks below. */

// ---------- EDIT: Residential / Commercial ----------
var reData = {
  res: { t: 'Residential', lead: 'Housing is driven by demand depth, approvals and execution. We help developers, funds and lenders judge whether a project or portfolio will sell, let and deliver as planned.',
    seg: ['Apartments and mid-market housing', 'Affordable housing', 'Rental and build-to-rent', 'Student housing and co-living', 'Senior living', 'Plotted and land development'],
    q: ['Will this project sell at the assumed price and pace?', 'Can it be completed within budget and on time?', 'What yield will a rental portfolio really deliver?'],
    f: ['Title, approvals and regulatory status', 'Sales velocity, pricing and absorption', 'Construction progress and cost to complete', 'Collections, escrow and cash-flow waterfall', 'Developer track record and counterparty strength'] },
  com: { t: 'Commercial', lead: 'Commercial value sits in leases. We test the quality of income, the strength of tenants and the cost of keeping an asset competitive, so you pay for what the building will earn.',
    seg: ['Offices and business parks', 'Retail and malls', 'Industrial and warehousing', 'Data centres', 'Hotels and hospitality', 'Mixed-use developments'],
    q: ['How secure is the income if a major tenant leaves?', 'Are passing rents above or below market?', 'What capex will keep the asset competitive?'],
    f: ['Rent roll, lease expiries and tenant covenant', 'Occupancy, vacancy and market rents', 'Operating costs, service charges and capex', 'Technical condition and sustainability credentials', 'Title, zoning and permitted use'] }
};

// ---------- EDIT: due diligence workstreams ----------
var ddTabs = [
  { k: 'Commercial and market', title: 'Commercial and market review', lead: 'Is the income real, is it sustainable, and does the business plan match the market?',
    aHead: 'What we examine', a: ['Rent roll, tenant mix and concentration', 'Lease expiry and break profile', 'Passing rents against market rents', 'Competing supply and demand drivers', 'Assumptions in the seller or sponsor business plan'],
    bHead: 'What you receive', b: ['A reconciled view of true income', 'Market-based rent and occupancy ranges', 'Key risks ranked by value impact'] },
  { k: 'Financial', title: 'Financial review', lead: 'We test the numbers behind the headline so price and terms reflect reality.',
    aHead: 'What we examine', a: ['Historical income and expenses', 'One-off items and normalisation adjustments', 'Service charge recoveries and arrears', 'Deposits, guarantees and debt-like items', 'Cash flow forecast and sensitivity cases'],
    bHead: 'What you receive', b: ['Adjusted net operating income', 'Net debt and working capital schedule', 'Points to raise on price and warranties'],
    note: 'Tax and structuring points are flagged and referred to your tax advisers.' },
  { k: 'Technical and physical', title: 'Technical and physical review', lead: 'We assess the condition of the building and what it will cost to keep it competitive.',
    aHead: 'What we examine', a: ['Building condition and survey reports', 'Capex and deferred maintenance backlog', 'Construction quality and progress (developments)', 'Compliance certificates and safety records', 'Utilities, access and infrastructure'],
    bHead: 'What you receive', b: ['A costed capex and maintenance plan', 'Delivery risk assessment for developments', 'Independent view on cost to complete'] },
  { k: 'Legal and regulatory', title: 'Legal and regulatory coordination', lead: 'We coordinate the legal workstream with your counsel and bring their findings into the commercial picture.',
    aHead: 'What we coordinate', a: ['Title chain and encumbrances', 'Zoning, permits and approvals', 'Lease terms and tenant rights', 'Litigation and disputes', 'Regulatory registrations and filings'],
    bHead: 'What you receive', b: ['A single issues list across all workstreams', 'Legal findings translated into value impact', 'Clear actions before signing'],
    note: 'We coordinate with your lawyers and do not provide legal opinions.' },
  { k: 'ESG and sustainability', title: 'ESG and sustainability review', lead: 'Energy, climate and social factors increasingly affect value, financing and exit.',
    aHead: 'What we examine', a: ['Energy and water performance', 'Green building certifications', 'Flood, heat and other climate exposure', 'Occupant health, safety and community factors', 'Direction of regulation and tenant expectations'],
    bHead: 'What you receive', b: ['A sustainability risk and opportunity register', 'Retrofit options with indicative cost', 'Inputs for lender and investor reporting'] }
];

// ---------- EDIT: investment strategies ----------
var strat = {
  core: { t: 'Core', d: 'Stabilised, high-quality assets in prime locations, producing steady income with little leverage.', w: ['Durability of income and tenant quality', 'Pricing against replacement cost and comparable sales', 'Exit liquidity in a weaker market'] },
  plus: { t: 'Core-plus', d: 'Mostly stabilised assets with modest upside from light refurbishment, leasing or management improvements.', w: ['Realism of rent and occupancy growth', 'Scope and cost of planned improvements', 'Sensitivity to interest rate changes'] },
  value: { t: 'Value-add', d: 'Assets that need renovation, repositioning or lease-up before they reach full value.', w: ['Capex budget, programme and contingency', 'Lease-up pace against market depth', 'Debt terms across the business plan'] },
  opp: { t: 'Opportunistic', d: 'Ground-up development, distressed purchases and complex situations with the widest range of outcomes.', w: ['Approvals, land title and construction risk', 'Demand at completion, not at launch', 'Funding plan and exit routes if the market turns'] },
  debt: { t: 'Real estate debt', d: 'Senior and mezzanine loans secured on property, where the question is protection rather than upside.', w: ['Loan-to-value and debt service cover under stress', 'Quality of the security and the sponsor', 'Recovery and enforcement route'] }
};

// ================= Behaviour (no need to edit below) =================
(function () {
  var reBody = document.getElementById('reBody'), reBtns = document.querySelectorAll('.re-toggle button');
  function renderRE(k) {
    var d = reData[k];
    reBtns.forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.k === k ? 'true' : 'false'); });
    document.getElementById('artRes').style.display = k === 'res' ? '' : 'none';
    document.getElementById('artCom').style.display = k === 'com' ? '' : 'none';
    reBody.innerHTML = '';
    var h = document.createElement('h3'); h.textContent = d.t; reBody.appendChild(h);
    var p = document.createElement('p'); p.textContent = d.lead; reBody.appendChild(p);
    var chips = document.createElement('div'); chips.className = 'chips';
    d.seg.forEach(function (x) { var s = document.createElement('span'); s.textContent = x; chips.appendChild(s); });
    reBody.appendChild(chips);
    var cols = document.createElement('div'); cols.className = 'cols2';
    var c1 = document.createElement('div'), h1 = document.createElement('h4'); h1.textContent = 'Questions we help answer'; c1.appendChild(h1); c1.appendChild(FOXUI.listOf(d.q));
    var c2 = document.createElement('div'), h2 = document.createElement('h4'); h2.textContent = 'What our diligence covers'; c2.appendChild(h2); c2.appendChild(FOXUI.listOf(d.f));
    cols.appendChild(c1); cols.appendChild(c2); reBody.appendChild(cols);
    var a = document.createElement('a'); a.className = 'btn dark'; a.href = '#contact'; a.textContent = 'Talk to our real estate team'; a.setAttribute('data-topic', 'Real estate advisory');
    reBody.appendChild(a);
  }
  reBtns.forEach(function (b) { b.addEventListener('click', function () { renderRE(b.dataset.k); }); });
  renderRE('res');

  FOXUI.vtabs(document.getElementById('ddTabs'), ddTabs, 0);

  var spBar = document.getElementById('spBar'), spDebt = document.getElementById('spDebt'), spDetail = document.getElementById('spDetail');
  var keys = ['core', 'plus', 'value', 'opp'], btns = {};
  spBar.innerHTML = '';
  function renderSP(k) {
    keys.forEach(function (x) { btns[x].setAttribute('aria-pressed', x === k ? 'true' : 'false'); });
    spDebt.setAttribute('aria-pressed', k === 'debt' ? 'true' : 'false');
    var d = strat[k]; spDetail.innerHTML = '';
    var h = document.createElement('h4'); h.textContent = d.t; spDetail.appendChild(h);
    var p = document.createElement('p'); p.textContent = d.d; spDetail.appendChild(p);
    var h5 = document.createElement('h5'); h5.textContent = 'What we test'; spDetail.appendChild(h5);
    spDetail.appendChild(FOXUI.listOf(d.w));
  }
  keys.forEach(function (k) {
    var b = document.createElement('button'); b.type = 'button'; b.textContent = strat[k].t; b.setAttribute('aria-pressed', 'false');
    b.addEventListener('click', function () { renderSP(k); }); spBar.appendChild(b); btns[k] = b;
  });
  spDebt.addEventListener('click', function () { renderSP('debt'); });
  renderSP('value');

  function num(id) { var v = parseFloat(document.getElementById(id).value); return isFinite(v) && v >= 0 ? v : 0; }
  function pct(v) { return (v * 100).toFixed(1) + '%'; }
  function setBar(id, v) { document.getElementById(id).style.width = Math.max(0, Math.min(100, v / 0.15 * 100)) + '%'; }
  function calc() {
    var price = num('c-price'), rent = num('c-rent'), opex = Math.min(num('c-opex'), 100) / 100, ltv = Math.min(num('c-ltv'), 95) / 100, rate = num('c-rate') / 100;
    var out = function (id, t) { document.getElementById(id).textContent = t; };
    if (price <= 0) { ['o-gross', 'o-net', 'o-eq', 'o-icr'].forEach(function (i) { out(i, '–'); }); ['b-gross', 'b-net', 'b-eq'].forEach(function (i) { setBar(i, 0); }); return; }
    var gross = rent / price, noi = rent * (1 - opex), net = noi / price, interest = price * ltv * rate, equity = price * (1 - ltv);
    var eq = equity > 0 ? (noi - interest) / equity : 0;
    out('o-gross', pct(gross)); out('o-net', pct(net)); out('o-eq', pct(eq));
    out('o-icr', interest > 0 ? (noi / interest).toFixed(2) + 'x' : 'No debt');
    setBar('b-gross', gross); setBar('b-net', net); setBar('b-eq', Math.max(eq, 0));
  }
  ['c-price', 'c-rent', 'c-opex', 'c-ltv', 'c-rate'].forEach(function (id) { document.getElementById(id).addEventListener('input', calc); });
  calc();
})();
