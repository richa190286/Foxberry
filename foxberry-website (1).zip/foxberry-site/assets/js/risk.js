/* Risk advisory page: interactive content.
   To change the wording of the panels, edit the data blocks below. */

// ---------- EDIT: sample risks on the heat map (illustrative) ----------
// L = likelihood 1-5, I = impact 1-5. "before" is before controls, "after" is after controls.
var risks = [
  { id: 'R1', t: 'Key supplier fails to deliver', before: [4, 4], after: [2, 4] },
  { id: 'R2', t: 'Cyber attack disrupts operations', before: [4, 5], after: [2, 5] },
  { id: 'R3', t: 'Regulatory breach and penalties', before: [3, 5], after: [1, 5] },
  { id: 'R4', t: 'Loss of key people', before: [4, 3], after: [2, 3] },
  { id: 'R5', t: 'Major project overruns budget', before: [3, 4], after: [3, 3] },
  { id: 'R6', t: 'Poor data quality drives bad decisions', before: [5, 3], after: [3, 2] }
];

// ---------- EDIT: risk universe ----------
var universe = [
  { k: 'Strategic', title: 'Strategic risk', lead: 'Risks that affect whether the organisation reaches its objectives: market shifts, competition, major investments and partnerships.',
    aHead: 'Typical exposures', a: ['Changing customer demand or competition', 'Failed or delayed acquisitions and investments', 'Over-reliance on one market or product', 'Misaligned strategy and capital allocation'],
    bHead: 'How we help', b: ['Strategic risk assessment for the board', 'Scenario and stress analysis', 'Risk appetite statements linked to strategy'] },
  { k: 'Financial', title: 'Financial risk', lead: 'Risks to cash, funding, reporting and returns.',
    aHead: 'Typical exposures', a: ['Liquidity and funding pressure', 'Interest rate and currency movements', 'Credit and counterparty losses', 'Errors or misstatement in reporting'],
    bHead: 'How we help', b: ['Liquidity and covenant monitoring', 'Financial controls review', 'Counterparty risk frameworks'] },
  { k: 'Operational', title: 'Operational risk', lead: 'Risks from people, processes and systems that fail to work as intended.',
    aHead: 'Typical exposures', a: ['Process breakdown and error', 'Supplier and outsourcing failure', 'Key-person dependency', 'Business disruption and safety events'],
    bHead: 'How we help', b: ['Process risk and control mapping', 'Business continuity and resilience planning', 'Third-party risk programmes'] },
  { k: 'Compliance', title: 'Compliance and regulatory risk', lead: 'Risks from breaching laws, regulations, contracts or internal policy.',
    aHead: 'Typical exposures', a: ['New or changing regulation', 'Licence and reporting obligations', 'Anti-bribery and sanctions breaches', 'Data protection failures'],
    bHead: 'How we help', b: ['Regulatory change and gap assessments', 'Compliance framework design', 'Monitoring and testing programmes'] },
  { k: 'Technology and cyber', title: 'Technology and cyber risk', lead: 'Risks from the systems, data and AI that the organisation depends on.',
    aHead: 'Typical exposures', a: ['Cyber attack and data breach', 'System outage and legacy technology', 'Weak access control', 'Unmanaged AI and model risk'],
    bHead: 'How we help', b: ['Technology and cyber risk assessments', 'Access and data governance reviews', 'AI and model risk frameworks'] },
  { k: 'Reputation and ESG', title: 'Reputation, ESG and climate risk', lead: 'Risks to trust, licence to operate and long-term value.',
    aHead: 'Typical exposures', a: ['Climate and physical risk to assets', 'Supply chain and labour practices', 'Governance failures and misconduct', 'Stakeholder and media scrutiny'],
    bHead: 'How we help', b: ['ESG and climate risk assessments', 'Disclosure readiness reviews', 'Crisis and reputation response planning'] }
];

// ================= Behaviour (no need to edit below) =================
(function () {
  FOXUI.vtabs(document.getElementById('unTabs'), universe, 0);

  var hm = document.getElementById('hm'), legend = document.getElementById('hmLegend'), tBtns = document.querySelectorAll('#hmToggle button');
  var colors = ['#CFE6F7', '#8EC3EE', '#3F93DC', '#0A3F7C'];
  function band(s) { return s <= 4 ? 0 : s <= 9 ? 1 : s <= 14 ? 2 : 3; }
  hm.innerHTML = ''; legend.innerHTML = '';
  for (var I = 5; I >= 1; I--) for (var L = 1; L <= 5; L++) {
    var cell = document.createElement('i'); cell.style.background = colors[band(L * I)]; hm.appendChild(cell);
  }
  var bubs = {};
  risks.forEach(function (r) {
    var b = document.createElement('div'); b.className = 'bub'; b.textContent = r.id; b.title = r.t; hm.appendChild(b); bubs[r.id] = b;
    var li = document.createElement('li'); li.innerHTML = '<b></b><span></span><em></em>';
    li.children[0].textContent = r.id; li.children[1].textContent = r.t; r.li = li; legend.appendChild(li);
  });
  function place(state) {
    tBtns.forEach(function (x) { x.setAttribute('aria-pressed', x.dataset.k === state ? 'true' : 'false'); });
    risks.forEach(function (r) {
      var p = r[state], b = bubs[r.id];
      b.style.left = ((p[0] - 1) * 20 + 10) + '%'; b.style.top = ((5 - p[1]) * 20 + 10) + '%';
      var sb = r.before[0] * r.before[1], sa = r.after[0] * r.after[1];
      r.li.children[2].textContent = state === 'before' ? 'Score ' + sb : 'Score ' + sb + ' to ' + sa;
    });
  }
  tBtns.forEach(function (x) { x.addEventListener('click', function () { place(x.dataset.k); }); });
  place('before');
})();
