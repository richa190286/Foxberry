/* Digital and data transformation page: interactive content.
   To change the wording of the panels, edit the data blocks below. */

// ---------- EDIT: data governance framework (wheel) ----------
var govData = [
  { k: 'Policies', t: 'Policies and standards', ic: 'i-doc', s: 'Clear rules that say how data is created, used, shared and retired.', items: ['Data policy and principles', 'Classification and retention standards', 'Definitions of key business terms', 'Exception and approval routes'] },
  { k: 'Ownership', t: 'Ownership and stewardship', ic: 'i-aug', s: 'Named people who are accountable for each important data set.', items: ['Data owners and stewards by domain', 'A data council with decision rights', 'Roles written into job descriptions', 'Escalation path for data issues'] },
  { k: 'Quality', t: 'Data quality', ic: 'i-check', s: 'Measured, monitored quality that people can see and trust.', items: ['Quality rules for critical data', 'Profiling and automated monitoring', 'Issue logging and root-cause fixes', 'Quality scorecards for leadership'] },
  { k: 'Catalogue', t: 'Catalogue and lineage', ic: 'i-db', s: 'A searchable record of what data exists, where it came from and who uses it.', items: ['Business glossary and data catalogue', 'End-to-end lineage for key reports', 'Metadata management', 'Impact analysis before changes'] },
  { k: 'Access', t: 'Access, privacy and security', ic: 'i-lock', s: 'The right people see the right data, and sensitive data is protected.', items: ['Role-based access model', 'Privacy and consent controls', 'Masking and anonymisation', 'Alignment with data protection law'] },
  { k: 'Metrics', t: 'Metrics and reporting', ic: 'i-gauge', s: 'Governance that proves its own value and keeps improving.', items: ['Governance maturity baseline', 'Adoption and compliance measures', 'Value tracking against business cases', 'Regular reporting to the council'] }
];

// ---------- EDIT: data maturity ladder ----------
var ladder = [
  { k: 'Ad hoc', n: 'Stage 1', t: 'Ad hoc', d: 'Data lives in spreadsheets and individual systems. Reports differ between teams and depend on a few people.', a: ['Multiple versions of key figures', 'Manual, person-dependent reporting', 'No agreed definitions'], b: ['Inventory critical data and reports', 'Agree definitions for the top ten metrics', 'Name an owner for each'] },
  { k: 'Reactive', n: 'Stage 2', t: 'Reactive', d: 'Some shared systems exist, but data problems are fixed after someone complains.', a: ['Some central reporting', 'Quality issues found late', 'Governance is informal'], b: ['Set quality rules for critical data', 'Stand up a basic data council', 'Choose a target platform'] },
  { k: 'Managed', n: 'Stage 3', t: 'Managed', d: 'A shared platform and standards exist for core domains, and quality is measured.', a: ['Central platform for key domains', 'Documented standards and owners', 'Quality measured regularly'], b: ['Extend to remaining domains', 'Add catalogue and lineage', 'Automate monitoring'] },
  { k: 'Governed', n: 'Stage 4', t: 'Governed', d: 'Governance is embedded in daily work. Data is easy to find, trusted and well controlled.', a: ['Catalogue, lineage and access in place', 'Stewards active in each domain', 'Data products with clear owners'], b: ['Enable self-service analytics', 'Operationalise AI on governed data', 'Track business value'] },
  { k: 'Optimised', n: 'Stage 5', t: 'Optimised', d: 'Data is a strategic asset. Teams build analytics and AI quickly, safely and at scale.', a: ['Reusable data products', 'Real-time and AI use cases in production', 'Continuous improvement'], b: ['Share data with partners safely', 'Monetise or productise data', 'Benchmark against peers'] }
];

// ================= Behaviour (no need to edit below) =================
(function () {
  FOXUI.filter('.cap-tab', '#capCards .card');
  FOXUI.wheel({ spokes: 'gspokes', nodes: 'gnodes', panel: 'govPanel', data: govData, contactTopic: 'Data and digital transformation', kicker: 'Data governance framework' });

  // Before / after architecture
  var b = document.getElementById('archBefore'), a = document.getElementById('archAfter'), btns = document.querySelectorAll('.arch .re-toggle button');
  function arch(k) {
    btns.forEach(function (x) { x.setAttribute('aria-pressed', x.dataset.k === k ? 'true' : 'false'); });
    b.style.display = k === 'before' ? '' : 'none'; a.style.display = k === 'after' ? '' : 'none';
  }
  btns.forEach(function (x) { x.addEventListener('click', function () { arch(x.dataset.k); }); });
  arch('before');

  // Maturity ladder
  var row = document.getElementById('ladder'), det = document.getElementById('ladDetail'), lb = [];
  row.innerHTML = '';
  function showL(i) {
    lb.forEach(function (x, k) { x.setAttribute('aria-pressed', k === i ? 'true' : 'false'); });
    var d = ladder[i]; det.innerHTML = '';
    var h = document.createElement('h3'); h.textContent = d.n + ': ' + d.t; det.appendChild(h);
    var p = document.createElement('p'); p.textContent = d.d; det.appendChild(p);
    var cols = document.createElement('div'); cols.className = 'cols2';
    [['What it looks like', d.a], ['How to move up', d.b]].forEach(function (pr) {
      var c = document.createElement('div'), hh = document.createElement('h4'); hh.textContent = pr[0]; c.appendChild(hh); c.appendChild(FOXUI.listOf(pr[1])); cols.appendChild(c);
    });
    det.appendChild(cols);
  }
  ladder.forEach(function (d, i) {
    var btn = document.createElement('button'); btn.type = 'button';
    btn.innerHTML = '<span>' + d.n + '</span>' + d.k; btn.addEventListener('click', function () { showL(i); });
    row.appendChild(btn); lb.push(btn);
  });
  showL(2);
})();
