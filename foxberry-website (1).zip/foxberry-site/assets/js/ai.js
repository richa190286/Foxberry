/* AI page: interactive content.
   To change the wording of the panels, edit the data blocks below. */

// ---------- EDIT: the eight AI capabilities (wheel) ----------
var aiData = [
  { k: 'Strategy', t: 'AI strategy and roadmap', ic: 'i-compass', s: 'Decide where AI belongs in your business, in what order, and what it should deliver.', items: ['Value-led portfolio of use cases', 'Business case and investment sequencing', 'Build, buy or partner choices', '12-month roadmap with named owners'] },
  { k: 'Responsible', t: 'Responsible AI', ic: 'i-scale', s: 'Use AI in ways your customers, regulators and employees can trust.', items: ['AI policy and risk-tiering framework', 'Testing for bias, privacy and explainability', 'Mapping to rules and standards that apply to you', 'Human oversight and clear accountability'] },
  { k: 'Augmented', t: 'Augmented AI', ic: 'i-aug', s: 'Put AI beside your people, strengthening their judgement rather than replacing it.', items: ['Copilots for analysts, advisers and operations teams', 'Human-in-the-loop workflow design', 'Task-by-task redesign of roles and processes', 'Training and change support so tools get used'] },
  { k: 'Agentic', t: 'Agentic AI and automation', ic: 'i-bot', s: 'Move from answering questions to completing work, safely and within set limits.', items: ['Selecting processes suited to agents', 'Guardrails, permissions and audit trails', 'Integration with core systems', 'Monitoring and escalation design'] },
  { k: 'Scalable', t: 'Scalable AI', ic: 'i-layers', s: 'Turn one successful pilot into a repeatable, reliable capability.', items: ['Reference architecture and shared platform', 'MLOps and LLMOps pipelines', 'Cost, performance and model-risk monitoring', 'Reusable components and delivery playbooks'] },
  { k: 'Data for AI', t: 'Data migration and modernisation for AI', ic: 'i-db', s: 'Migrate and modernise the data your AI depends on so it works in production.', items: ['Data estate assessment and migration plan', 'Cloud and lakehouse modernisation', 'Data quality, lineage and governance', 'Pipelines for structured and unstructured data'] },
  { k: 'Best practice', t: 'AI best practices and operating model', ic: 'i-check', s: 'Adopt proven ways of working from the start instead of learning them the hard way.', items: ['AI centre of excellence and operating model', 'Delivery standards, playbooks and templates', 'Vendor and model selection criteria', 'Skills, roles and capability building'] },
  { k: 'Readiness', t: 'AI readiness assessment', ic: 'i-gauge', s: 'A clear, practical baseline of where you stand today and what to fix first.', items: ['Review of strategy, data, technology, talent and governance', 'Benchmark against practical maturity levels', 'Prioritised gaps by effort and impact', 'Executive summary with a recommended path'] }
];

// ---------- EDIT: use cases by function ----------
var useCases = [
  { k: 'Finance', title: 'Finance', lead: 'AI can remove repetitive effort from the close, forecasting and review cycles, and give finance teams more time for judgement.',
    aHead: 'Example use cases', a: ['Reconciliation and period-end close support', 'Forecasting and scenario analysis', 'Data extraction from invoices and contracts', 'Document review during due diligence'],
    bHead: 'What makes it work', b: ['Clean, reconciled source data', 'Clear review and approval steps', 'An audit trail for every output'] },
  { k: 'Operations', title: 'Operations', lead: 'The strongest operations use cases combine prediction with a workflow that people actually follow.',
    aHead: 'Example use cases', a: ['Demand and capacity planning', 'Predictive maintenance', 'Exception handling in supply chains', 'Copilots for planners and coordinators'],
    bHead: 'What makes it work', b: ['Reliable sensor and system data', 'Integration with planning tools', 'Frontline involvement from day one'] },
  { k: 'Customer', title: 'Customer and sales', lead: 'Customer-facing AI needs strong guardrails and a smooth hand-off to a person.',
    aHead: 'Example use cases', a: ['Service assistants with human hand-off', 'Proposal and response drafting', 'Personalised recommendations', 'Analysis of feedback and sentiment'],
    bHead: 'What makes it work', b: ['Approved knowledge sources', 'Tone, privacy and brand controls', 'Clear escalation rules'] },
  { k: 'Risk and compliance', title: 'Risk and compliance', lead: 'AI can widen coverage and speed up monitoring, provided its own risks are managed.',
    aHead: 'Example use cases', a: ['Anomaly detection in transactions', 'Mapping policies to regulations', 'Screening of third parties', 'Monitoring of model performance and drift'],
    bHead: 'What makes it work', b: ['Explainable outputs', 'Documented validation', 'Human decision on every material case'] },
  { k: 'Real estate', title: 'Real estate', lead: 'Property data is scattered across leases, reports and spreadsheets, which makes it well suited to AI-assisted analysis.',
    aHead: 'Example use cases', a: ['Lease abstraction and rent roll building', 'Comparable-sales and valuation support', 'Tenant and demand analytics', 'Building energy optimisation'],
    bHead: 'What makes it work', b: ['Consistent data across assets', 'Verification by experienced analysts', 'Links to the underwriting model'] }
];

// ---------- EDIT: readiness questions (svc = index of the capability above to recommend) ----------
var questions = [
  { q: 'We have identified specific business problems where AI could create value.', svc: 0 },
  { q: 'Our key data is accessible, documented and of known quality.', svc: 5 },
  { q: 'Our technology can support AI workloads and connect to core systems.', svc: 4 },
  { q: 'We have clear policies and owners for AI risk, privacy and ethics.', svc: 1 },
  { q: 'Our people have the skills and time to use AI in their daily work.', svc: 2 }
];

// ================= Behaviour (no need to edit below) =================
(function () {
  var selectAI = FOXUI.wheel({ spokes: 'spokes', nodes: 'nodes', panel: 'aiPanel', data: aiData, contactTopic: 'AI advisory', kicker: 'Foxberry AI practice' });
  FOXUI.vtabs(document.getElementById('ucTabs'), useCases, 0);

  var form = document.getElementById('readyForm'); form.innerHTML = '';
  var opts = [['Yes', 2], ['Partly', 1], ['Not yet', 0]];
  questions.forEach(function (qq, i) {
    var fs = document.createElement('fieldset'); fs.className = 'q';
    var lg = document.createElement('legend'); lg.textContent = qq.q; fs.appendChild(lg);
    var wrap = document.createElement('div'); wrap.className = 'segs';
    opts.forEach(function (o) {
      var lab = document.createElement('label'); lab.className = 'seg';
      var inp = document.createElement('input'); inp.type = 'radio'; inp.name = 'q' + i; inp.value = o[1];
      var sp = document.createElement('span'); sp.textContent = o[0];
      lab.appendChild(inp); lab.appendChild(sp); wrap.appendChild(lab);
    });
    fs.appendChild(wrap); form.appendChild(fs);
  });
  var arc = document.getElementById('gArc'), gNum = document.getElementById('gNum');
  var rTitle = document.getElementById('rTitle'), rDesc = document.getElementById('rDesc'), rRecs = document.getElementById('rRecs'), rList = document.getElementById('rList');
  form.addEventListener('change', function () {
    var scores = [], answered = 0;
    questions.forEach(function (qq, i) {
      var c = form.querySelector('input[name="q' + i + '"]:checked');
      if (c) { answered++; scores.push({ i: i, v: +c.value }); } else scores.push({ i: i, v: null });
    });
    if (answered < questions.length) {
      rTitle.textContent = answered + ' of ' + questions.length + ' answered';
      rDesc.textContent = 'Answer all five questions to see where you stand and which services matter most.';
      rRecs.hidden = true; return;
    }
    var total = scores.reduce(function (a, b) { return a + b.v; }, 0);
    gNum.textContent = total;
    arc.setAttribute('stroke-dasharray', (252 * total / 10) + ' 252');
    var tier = total >= 8 ? ['Ready to scale', 'You are well placed. Focus on governance, platform and operating model so AI scales safely.']
             : total >= 4 ? ['Building momentum', 'You have foundations in place. The priority is closing specific gaps so pilots can reach production.']
             : ['Getting started', 'You have the most to gain from a clear strategy and a solid data foundation before investing in tools.'];
    rTitle.textContent = tier[0]; rDesc.textContent = tier[1];
    var gaps = scores.filter(function (x) { return x.v < 2; }).sort(function (a, b) { return a.v - b.v; }).slice(0, 3).map(function (x) { return questions[x.i].svc; });
    if (!gaps.length) gaps = [4, 6];
    rList.innerHTML = '';
    gaps.forEach(function (idx) {
      var a = document.createElement('a'); a.href = '#capabilities'; a.textContent = aiData[idx].t;
      a.addEventListener('click', function () { selectAI(idx); });
      rList.appendChild(a);
    });
    rRecs.hidden = false;
  });
})();
