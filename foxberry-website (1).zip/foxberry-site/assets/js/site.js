/* ==========================================================
   Foxberry Consulting: shared script
   ----------------------------------------------------------
   1. SETTINGS: edit the block below (name, email, phone...).
   2. The header, footer and contact form are defined here once
      and appear on every page.
   3. Edit mode: add ?edit to any page address to change text
      on the page and download the updated file.
   ========================================================== */

// ---------- 1. SETTINGS (edit these) ----------
window.FOX = {
  name: 'Foxberry Consulting',
  domain: 'https://www.foxberryconsulting.com',
  email: 'hello@foxberryconsulting.com',
  phone: '[Phone number to be added]',
  address: '[Office address to be added]',
  linkedin: '#',                       // e.g. https://www.linkedin.com/company/your-company
  // To receive form submissions without opening the visitor's email app,
  // create a free form at formspree.io and paste its address here,
  // for example 'https://formspree.io/f/abcdwxyz'. Leave empty to use email.
  formEndpoint: '',
  topics: ['M&A advisory', 'Financial due diligence', 'Real estate due diligence', 'Real estate advisory',
           'Corporate restructuring', 'Data and digital transformation', 'AI advisory', 'AI Studio workshop',
           'Risk advisory', 'Careers', 'Not sure yet']
};

(function () {
  var F = window.FOX;
  var page = document.body.getAttribute('data-page') || 'home';
  var params = new URLSearchParams(location.search);
  var editMode = params.has('edit');

  // ---------- Icon sprite ----------
  var sprite = document.createElement('div');
  sprite.className = 'fox-sprite';
  sprite.innerHTML = `<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <defs>
    <symbol id="i-ma" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="16" r="8"/><circle cx="20" cy="16" r="8"/><path d="M16 10.5a8 8 0 0 1 0 11"/></symbol>
    <symbol id="i-fdd" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 26V16M11 26V10M17 26v-8"/><circle cx="22" cy="12" r="5"/><path d="M26 16l3.5 3.5"/></symbol>
    <symbol id="i-re" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 28V8l11-4v24M16 12l11 4v12M3 28h26"/><path d="M9 12h3M9 17h3M9 22h3M21 20h2M21 24h2"/></symbol>
    <symbol id="i-rs" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M27 12a11 11 0 0 0-20-3M5 20a11 11 0 0 0 20 3"/><path d="M7 4v5h5M25 28v-5h-5"/><circle cx="16" cy="16" r="2.5"/></symbol>
    <symbol id="i-dd" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="16" cy="16" r="3.5"/><circle cx="5.5" cy="7" r="2.5"/><circle cx="26.5" cy="7" r="2.5"/><circle cx="5.5" cy="25" r="2.5"/><circle cx="26.5" cy="25" r="2.5"/><path d="M7.5 8.7l5.8 4.7M24.5 8.7l-5.8 4.7M7.5 23.3l5.8-4.7M24.5 23.3l-5.8-4.7"/></symbol>
    <symbol id="i-ai" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="8" y="8" width="16" height="16" rx="3"/><path d="M12 4v4M20 4v4M12 24v4M20 24v4M4 12h4M4 20h4M24 12h4M24 20h4"/><path d="M16 12.5l1.4 2.9 2.9 1.4-2.9 1.4L16 21l-1.4-2.8-2.9-1.4 2.9-1.4z"/></symbol>
    <symbol id="i-rk" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M16 3l11 4v8c0 7-4.6 11.6-11 14C9.6 26.6 5 22 5 15V7z"/><path d="M11 16l3.5 3.5L21 12.5"/></symbol>
    <symbol id="i-fin" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12l13-7 13 7M6 12v12M12 12v12M20 12v12M26 12v12M3 27h26"/></symbol>
    <symbol id="i-tech" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="6" width="26" height="17" rx="2"/><path d="M11 28h10M16 23v5M10 15l-2.5 2 2.5 2M22 15l2.5 2-2.5 2M17 13l-2 8"/></symbol>
    <symbol id="i-hc" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M16 28S4 20.5 4 12.500A6.5 6.5 0 0 1 16 9a6.5 6.5 0 0 1 12 3.500C28 20.5 16 28 16 28z"/><path d="M8 16h5l2-4 3 7 2-3h4"/></symbol>
    <symbol id="i-mf" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 28V14l8 5v-5l8 5v-5l8 5v9z"/><path d="M23 14V4h4v14M3 28h26"/></symbol>
    <symbol id="i-cons" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 9h22l-2 14H7z"/><path d="M12 9V6a4 4 0 0 1 8 0v3"/></symbol>
    <symbol id="i-en" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 3L7 18h8l-1 11 11-15h-8z"/></symbol>
    <symbol id="i-pub" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M16 3L3 10h26zM6 10v13M12 10v13M20 10v13M26 10v13M3 27h26"/></symbol>
    <symbol id="i-compass" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="16" cy="16" r="12"/><path d="M21 11l-3 7-7 3 3-7z"/></symbol>
    <symbol id="i-scale" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M16 5v21M9 27h14M6 9h20"/><path d="M6 9l-3.5 8a3.5 3.5 0 0 0 7 0zM26 9l-3.5 8a3.5 3.5 0 0 0 7 0z"/></symbol>
    <symbol id="i-aug" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="11" r="4.5"/><path d="M3 28c0-5.5 4-9 9-9s9 3.5 9 9"/><path d="M25 3v9M20.5 7.500h9"/></symbol>
    <symbol id="i-bot" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="10" width="20" height="15" rx="4"/><path d="M16 10V6M12 17v1M20 17v1M12 21.500h8M3 15v5M29 15v5"/><circle cx="16" cy="4.5" r="1.5"/></symbol>
    <symbol id="i-layers" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M16 4l12 6-12 6-12-6zM4 16l12 6 12-6M4 22l12 6 12-6"/></symbol>
    <symbol id="i-db" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="16" cy="7" rx="10" ry="4"/><path d="M6 7v18c0 2.2 4.5 4 10 4s10-1.8 10-4V7M6 16c0 2.2 4.5 4 10 4s10-1.8 10-4"/></symbol>
    <symbol id="i-check" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8l2.5 2.500L11 5.500M4 17l2.5 2.500L11 14.500M16 8h12M16 17h12M4 26h24"/></symbol>
    <symbol id="i-gauge" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 24a12 12 0 1 1 24 0M16 24l6-9M8 24h2M22 24h2M16 11v2"/></symbol>
    <symbol id="i-home" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 15L16 5l12 10M7 13v14h18V13M13 27v-8h6v8"/></symbol>
    <symbol id="i-trend" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 27h26M5 22l7-7 5 5 10-12M20 8h7v7"/></symbol>
    <symbol id="i-cloud" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 25a6 6 0 0 1-.6-12A8 8 0 0 1 23.6 14 5.5 5.5 0 0 1 23 25z"/></symbol>
    <symbol id="i-link" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M13 19a5 5 0 0 0 7 0l5-5a5 5 0 0 0-7-7l-1.5 1.500M19 13a5 5 0 0 0-7 0l-5 5a5 5 0 0 0 7 7l1.5-1.5"/></symbol>
    <symbol id="i-lock" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="14" width="20" height="14" rx="3"/><path d="M10 14v-4a6 6 0 0 1 12 0v4M16 19v4"/></symbol>
    <symbol id="i-search" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="14" cy="14" r="9"/><path d="M21 21l8 8"/></symbol>
    <symbol id="i-pulse" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 17h6l3-9 5 18 4-14 3 5h7"/></symbol>
    <symbol id="i-leaf" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 26C6 14 14 6 28 5c0 14-8 22-18 21M6 26l10-10"/></symbol>
    <symbol id="i-doc" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3h13l5 5v21H7zM20 3v5h5M11 14h10M11 19h10M11 24h6"/></symbol>
    <symbol id="i-arrow" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 8h12M9 3l5 5-5 5"/></symbol>
  </defs>
</svg>`;
  document.body.insertBefore(sprite, document.body.firstChild);

  // ---------- Header ----------
  function cur(p) { return page === p ? ' aria-current="page"' : ''; }
  var header = `
  <div class="util"><div class="wrap"><a href="index.html#insights">Insights</a><a href="index.html#careers">Careers</a><a href="#contact">Contact</a></div></div>
  <header class="site">
    <div class="wrap bar">
      <a class="brand" href="index.html" aria-label="${F.name} home"><picture><source media="(prefers-color-scheme: dark)" srcset="assets/img/logo-horizontal-reverse.svg"><img src="assets/img/logo-horizontal-color.svg" alt="${F.name}" height="46"></picture></a>
      <button class="menu-toggle" id="menuBtn" aria-expanded="false" aria-controls="nav">Menu</button>
      <nav class="primary" id="nav" aria-label="Primary">
        <div class="dd" id="dd">
          <button type="button" aria-expanded="false" aria-controls="mega" id="ddBtn">Services
            <svg width="10" height="6" viewBox="0 0 10 6" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M1 1l4 4 4-4"/></svg>
          </button>
          <div class="mega" id="mega">
            <div class="wrap">
              <div class="intro"><h4>How we help</h4><p>Advisory across transactions, technology, AI and risk, delivered by one integrated team.</p></div>
              <div><h5>Transactions and restructuring</h5><ul>
                <li><a href="index.html#services">M&amp;A advisory</a></li>
                <li><a href="index.html#services">Financial due diligence</a></li>
                <li><a href="real-estate.html">Real estate advisory and due diligence</a></li>
                <li><a href="index.html#services">Corporate restructuring</a></li></ul></div>
              <div><h5>Technology and transformation</h5><ul>
                <li><a href="digital-transformation.html">Digital and data transformation</a></li>
                <li><a href="digital-transformation.html#modernisation">Data modernisation</a></li>
                <li><a href="digital-transformation.html#governance">Data governance</a></li>
                <li><a href="ai.html">AI advisory and Responsible AI</a></li></ul></div>
              <div><h5>Risk</h5><ul>
                <li><a href="risk-advisory.html">Risk advisory</a></li>
                <li><a href="risk-advisory.html#heatmap">Enterprise risk management</a></li>
                <li><a href="risk-advisory.html#universe">Cyber and third-party risk</a></li></ul></div>
            </div>
          </div>
        </div>
        <a href="real-estate.html"${cur('real-estate')}>Real estate</a>
        <a href="ai.html"${cur('ai')}>AI</a>
        <a href="digital-transformation.html"${cur('digital')}>Digital and data</a>
        <a href="risk-advisory.html"${cur('risk')}>Risk advisory</a>
        <a href="index.html#people">Our people</a>
        <a href="index.html#careers">Careers</a>
      </nav>
      <a class="btn dark" href="#contact" style="padding:12px 22px">Contact us</a>
    </div>
  </header>`;
  var h = document.getElementById('site-header');
  if (h) h.innerHTML = header;

  // ---------- Footer ----------
  var footer = `
  <footer>
    <div class="wrap">
      <div class="fgrid">
        <div>
          <a class="brand" href="index.html"><img src="assets/img/logo-horizontal-reverse.svg" alt="${F.name}" height="56"></a>
          <p style="max-width:34ch">Independent advice on transactions, transformation, AI and risk.</p>
        </div>
        <div><h5>Practices</h5><ul>
          <li><a href="real-estate.html">Real estate advisory</a></li>
          <li><a href="ai.html">AI advisory</a></li>
          <li><a href="digital-transformation.html">Digital and data transformation</a></li>
          <li><a href="risk-advisory.html">Risk advisory</a></li>
          <li><a href="index.html#services">All services</a></li></ul></div>
        <div><h5>Firm</h5><ul>
          <li><a href="index.html#approach">Approach</a></li>
          <li><a href="index.html#people">Our people</a></li>
          <li><a href="index.html#insights">Insights</a></li>
          <li><a href="index.html#careers">Careers</a></li></ul></div>
        <div><h5>Contact</h5><ul>
          <li><a href="#contact">Start a conversation</a></li>
          <li><a href="mailto:${F.email}">${F.email}</a></li>
          <li><a href="${F.linkedin}">LinkedIn</a></li></ul></div>
      </div>
      <div class="fbase"><div>&copy; ${new Date().getFullYear()} ${F.name}. All rights reserved.</div><div><a href="#">Privacy</a> &nbsp;&nbsp; <a href="#">Terms</a></div></div>
    </div>
  </footer>`;
  var f = document.getElementById('site-footer');
  if (f) f.innerHTML = footer;

  // ---------- Contact section ----------
  var c = document.getElementById('site-contact');
  if (c) {
    var defTopic = c.getAttribute('data-topic') || 'Not sure yet';
    var opts = F.topics.map(function (t) { return '<option' + (t === defTopic ? ' selected' : '') + '>' + t.replace(/&/g, '&amp;') + '</option>'; }).join('');
    c.innerHTML = `
    <section class="contact" id="contact">
      <div class="wrap">
        <div class="side">
          <h2>Tell us what you are working on</h2>
          <p>A short note is enough. A partner will reply within two working days to arrange an initial conversation, with no obligation.</p>
          <div class="office"><strong>Get in touch</strong><a href="mailto:${F.email}">${F.email}</a><br>${F.address}<br>${F.phone}</div>
        </div>
        <form class="enquiry" id="enquiry" novalidate>
          <div class="row">
            <label>Name<input type="text" id="f-name" autocomplete="name" required></label>
            <label>Work email<input type="email" id="f-email" autocomplete="email" required></label>
          </div>
          <div class="row">
            <label>Company<input type="text" id="f-company" autocomplete="organization"></label>
            <label>Area of interest<select id="f-topic">${opts}</select></label>
          </div>
          <label>How can we help?<textarea id="f-msg" required></textarea></label>
          <p id="form-status" role="status"></p>
          <div><button type="submit" class="btn dark">Send enquiry <svg class="arrow"><use href="#i-arrow"/></svg></button></div>
          <p class="note">Everything you share is treated as confidential.</p>
        </form>
      </div>
    </section>`;
    document.getElementById('enquiry').addEventListener('submit', function (e) {
      e.preventDefault();
      var g = function (id) { return document.getElementById(id).value.trim(); };
      var data = { name: g('f-name'), email: g('f-email'), company: g('f-company'), topic: g('f-topic'), message: g('f-msg') };
      var st = document.getElementById('form-status');
      if (!data.name || !data.email || !data.message) { st.textContent = 'Please enter your name, work email and a short message.'; return; }
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(data.email)) { st.textContent = 'Please enter a valid email address.'; return; }
      if (F.formEndpoint) {
        st.textContent = 'Sending...';
        fetch(F.formEndpoint, { method: 'POST', headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' }, body: JSON.stringify(data) })
          .then(function (r) {
            if (!r.ok) throw new Error('bad status');
            st.textContent = 'Thank you. We have received your enquiry and will reply within two working days.';
            document.getElementById('enquiry').reset();
          })
          .catch(function () { st.textContent = 'Sorry, that did not send. Please email us at ' + F.email + '.'; });
      } else {
        st.textContent = 'Opening your email app to send this enquiry.';
        var body = 'Name: ' + data.name + '\nEmail: ' + data.email + '\nCompany: ' + data.company + '\nArea of interest: ' + data.topic + '\n\n' + data.message;
        window.location.href = 'mailto:' + F.email + '?subject=' + encodeURIComponent('Enquiry: ' + data.topic) + '&body=' + encodeURIComponent(body);
      }
    });
  }

  // ---------- Menu ----------
  var menuBtn = document.getElementById('menuBtn'), nav = document.getElementById('nav');
  var dd = document.getElementById('dd'), ddBtn = document.getElementById('ddBtn');
  function setDD(o) { dd.classList.toggle('open', o); ddBtn.setAttribute('aria-expanded', o); }
  if (menuBtn) {
    menuBtn.addEventListener('click', function () { var o = nav.classList.toggle('open'); menuBtn.setAttribute('aria-expanded', o); });
    ddBtn.addEventListener('click', function () { setDD(!dd.classList.contains('open')); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setDD(false); });
    document.addEventListener('click', function (e) { if (!dd.contains(e.target)) setDD(false); });
    var mq = window.matchMedia('(min-width: 1121px)');
    dd.addEventListener('mouseenter', function () { if (mq.matches) setDD(true); });
    dd.addEventListener('mouseleave', function () { if (mq.matches) setDD(false); });
    nav.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', function () { setDD(false); nav.classList.remove('open'); }); });
    if (['real-estate', 'ai', 'digital', 'risk'].indexOf(page) > -1) dd.classList.add('on');
  }

  // ---------- Buttons that preselect a contact topic ----------
  document.addEventListener('click', function (e) {
    var a = e.target.closest ? e.target.closest('[data-topic]') : null;
    var sel = document.getElementById('f-topic');
    if (a && sel) sel.value = a.getAttribute('data-topic');
  });

  // ---------- In-page navigation highlight ----------
  var sub = document.querySelectorAll('.subnav a[href^="#"]');
  if (sub.length && 'IntersectionObserver' in window) {
    var map = {};
    sub.forEach(function (a) { var t = document.getElementById(a.getAttribute('href').slice(1)); if (t) map[t.id] = a; });
    var io2 = new IntersectionObserver(function (en) {
      en.forEach(function (x) {
        if (x.isIntersecting) {
          sub.forEach(function (a) { a.classList.remove('on'); });
          if (map[x.target.id]) { map[x.target.id].classList.add('on'); map[x.target.id].scrollIntoView({ block: 'nearest', inline: 'center' }); }
        }
      });
    }, { rootMargin: '-40% 0px -55% 0px' });
    Object.keys(map).forEach(function (id) { io2.observe(document.getElementById(id)); });
  }

  // ---------- Counters ----------
  var nums = document.querySelectorAll('[data-count]');
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function setNum(el, v) { el.textContent = v + (el.dataset.suffix || ''); }
  function run(el) {
    var end = +el.dataset.count;
    if (reduce) { setNum(el, end); return; }
    var start = null, dur = 1400;
    function step(ts) { if (!start) start = ts; var p = Math.min((ts - start) / dur, 1); setNum(el, Math.round(end * (1 - Math.pow(1 - p, 3)))); if (p < 1) requestAnimationFrame(step); }
    requestAnimationFrame(step);
  }
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (en) { en.forEach(function (x) { if (x.isIntersecting) { run(x.target); io.unobserve(x.target); } }); }, { threshold: .4 });
    nums.forEach(function (n) { io.observe(n); });
  } else { nums.forEach(function (n) { setNum(n, +n.dataset.count); }); }

  // ---------- Helpers shared by page scripts ----------
  window.FOXUI = {
    listOf: function (items) { var ul = document.createElement('ul'); items.forEach(function (x) { var li = document.createElement('li'); li.textContent = x; ul.appendChild(li); }); return ul; },
    // Vertical tabs. tabs: [{k, lead, title, aHead, a:[...], bHead, b:[...], note}]
    vtabs: function (root, tabs, startIndex) {
      root.innerHTML = '';
      var list = document.createElement('div'); list.className = 'list'; list.setAttribute('role', 'tablist');
      var pane = document.createElement('div'); pane.className = 'pane'; pane.setAttribute('aria-live', 'polite');
      var btns = [];
      function show(i) {
        btns.forEach(function (b, k) { b.setAttribute('aria-selected', k === i ? 'true' : 'false'); b.tabIndex = k === i ? 0 : -1; });
        var d = tabs[i]; pane.innerHTML = '';
        var h = document.createElement('h3'); h.textContent = d.title || d.k; pane.appendChild(h);
        var p = document.createElement('p'); p.textContent = d.lead; pane.appendChild(p);
        var cols = document.createElement('div'); cols.className = 'cols2';
        [[d.aHead, d.a], [d.bHead, d.b]].forEach(function (pair) {
          if (!pair[1]) return;
          var col = document.createElement('div'), hh = document.createElement('h4'); hh.textContent = pair[0]; col.appendChild(hh); col.appendChild(window.FOXUI.listOf(pair[1])); cols.appendChild(col);
        });
        pane.appendChild(cols);
        if (d.note) { var n = document.createElement('p'); n.className = 'note'; n.textContent = d.note; pane.appendChild(n); }
      }
      tabs.forEach(function (d, i) {
        var b = document.createElement('button'); b.type = 'button'; b.setAttribute('role', 'tab'); b.textContent = d.k;
        b.addEventListener('click', function () { show(i); });
        b.addEventListener('keydown', function (e) {
          var n = tabs.length, j = null;
          if (e.key === 'ArrowDown' || e.key === 'ArrowRight') j = (i + 1) % n;
          if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') j = (i + n - 1) % n;
          if (j !== null) { e.preventDefault(); show(j); btns[j].focus(); }
        });
        list.appendChild(b); btns.push(b);
      });
      root.appendChild(list); root.appendChild(pane); show(startIndex || 0);
    },
    // Clickable hub-and-spoke wheel. cfg: {svg, spokes, nodes, panel, data, contactTopic, kicker, count, topLabelIdx:[...]}
    wheel: function (cfg) {
      var NS = 'http://www.w3.org/2000/svg', n = cfg.data.length, CX = 280, CY = 280, R = 190, els = [];
      function mk(t, a) { var e = document.createElementNS(NS, t); for (var k in a) e.setAttribute(k, a[k]); return e; }
      var sp = document.getElementById(cfg.spokes), ng = document.getElementById(cfg.nodes), panel = document.getElementById(cfg.panel);
      sp.innerHTML = ''; ng.innerHTML = '';
      var step = 360 / n;
      cfg.data.forEach(function (d, i) {
        var a = (-90 + i * step) * Math.PI / 180; d.x = CX + R * Math.cos(a); d.y = CY + R * Math.sin(a);
        sp.appendChild(mk('line', { x1: CX, y1: CY, x2: d.x, y2: d.y, stroke: '#8FD3F7', 'stroke-opacity': '.25' }));
      });
      function select(i) {
        var d = cfg.data[i];
        els.forEach(function (e, k) { e.setAttribute('aria-pressed', k === i ? 'true' : 'false'); });
        panel.innerHTML = '';
        function add(tag, txt, cls) { var e = document.createElement(tag); e.textContent = txt; if (cls) e.className = cls; panel.appendChild(e); return e; }
        add('div', cfg.kicker, 'kicker'); add('h3', d.t); add('p', d.s); add('h4', 'What you get');
        panel.appendChild(window.FOXUI.listOf(d.items));
        var b = document.createElement('a'); b.className = 'btn'; b.href = '#contact'; b.textContent = 'Discuss this with us'; b.setAttribute('data-topic', cfg.contactTopic); panel.appendChild(b);
      }
      cfg.data.forEach(function (d, i) {
        var ang = (-90 + i * step); var up = Math.sin(ang * Math.PI / 180) < -0.2;
        var g = mk('g', { 'class': 'node', tabindex: '0', role: 'button', 'aria-pressed': 'false', 'aria-label': d.t });
        g.appendChild(mk('circle', { 'class': 'bg', cx: d.x, cy: d.y, r: 36 }));
        g.appendChild(mk('use', { href: '#' + d.ic, x: d.x - 14, y: d.y - 14, width: 28, height: 28 }));
        var t = mk('text', { x: d.x, y: up ? d.y - 48 : d.y + 62, 'text-anchor': 'middle' }); t.textContent = d.k; g.appendChild(t);
        g.addEventListener('click', function () { select(i); });
        g.addEventListener('keydown', function (e) {
          if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); select(i); }
          if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { e.preventDefault(); select((i + 1) % n); els[(i + 1) % n].focus(); }
          if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { e.preventDefault(); select((i + n - 1) % n); els[(i + n - 1) % n].focus(); }
        });
        ng.appendChild(g); els.push(g);
      });
      select(cfg.start || 0);
      return select;
    },
    // Filter tab buttons (.tab[data-filter]) and cards ([data-g])
    filter: function (tabSel, cardSel) {
      var tabs = document.querySelectorAll(tabSel), cards = document.querySelectorAll(cardSel);
      function apply(f) {
        tabs.forEach(function (t) { t.setAttribute('aria-pressed', t.dataset.filter === f ? 'true' : 'false'); });
        cards.forEach(function (c) { var g = c.dataset.g.split(' '); c.hidden = !(f === 'all' || g.indexOf(f) > -1 || g.indexOf('all') > -1); });
      }
      tabs.forEach(function (t) { t.addEventListener('click', function () { apply(t.dataset.filter); }); });
      apply('all');
    }
  };

  // ---------- 3. EDIT MODE (?edit) ----------
  if (editMode) {
    document.body.classList.add('edit-mode');
    var sel = 'main h1, main h2, main h3, main h4, main h5, main p, main li, main summary, main .who span, main .chips span, main .lbl, main a.btn, main a.textlink, main .outcome, .crumbs';
    document.querySelectorAll(sel).forEach(function (el) {
      if (el.closest('[data-dynamic], form, svg, .no-edit, [data-count]')) return;
      if (el.classList.contains('outcome')) return;
      el.setAttribute('contenteditable', 'true');
      el.setAttribute('spellcheck', 'true');
    });
    document.querySelectorAll('details').forEach(function (d) { d.open = true; });
    document.addEventListener('click', function (e) {
      if (e.target.closest('.fox-editbar, .fox-dl')) return;
      if (e.target.closest('summary, a')) e.preventDefault();
    }, true);
    var bar = document.createElement('div');
    bar.className = 'fox-editbar';
    bar.innerHTML = '<span>Edit mode: click any text to change it.</span><button type="button" class="btn" id="foxSave">Download this page</button><button type="button" class="ghost" id="foxExit">Exit</button>';
    document.body.appendChild(bar);
    document.getElementById('foxExit').addEventListener('click', function () { params.delete('edit'); location.search = params.toString(); });
    document.getElementById('foxSave').addEventListener('click', function () {
      var doc = document.documentElement.cloneNode(true);
      doc.querySelectorAll('[contenteditable]').forEach(function (e) { e.removeAttribute('contenteditable'); e.removeAttribute('spellcheck'); });
      doc.querySelectorAll('[data-dynamic]').forEach(function (e) { e.innerHTML = ''; });
      ['site-header', 'site-footer', 'site-contact'].forEach(function (id) { var e = doc.querySelector('#' + id); if (e) e.innerHTML = ''; });
      doc.querySelectorAll('.fox-sprite, .fox-editbar').forEach(function (e) { e.remove(); });
      doc.querySelectorAll('.subnav a.on').forEach(function (a) { a.classList.remove('on'); });
      doc.querySelectorAll('[data-count]').forEach(function (e) { e.textContent = '0'; });
      doc.querySelectorAll('details').forEach(function (d) { d.removeAttribute('open'); });
      doc.querySelector('body').classList.remove('edit-mode');
      if (!doc.querySelector('body').getAttribute('class')) doc.querySelector('body').removeAttribute('class');
      var html = '<!DOCTYPE html>\n' + doc.outerHTML;
      var blob = new Blob([html], { type: 'text/html' });
      var a = document.createElement('a');
      a.className = 'fox-dl';
      a.href = URL.createObjectURL(blob);
      a.download = (location.pathname.split('/').pop() || 'index.html');
      document.body.appendChild(a); a.click(); a.remove();
    });
  }
})();
