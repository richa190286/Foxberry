# Foxberry Consulting website

A five-page static website. No build step, no database, no framework: just HTML, CSS and JavaScript files that any web host can serve.

| File | What it is |
|---|---|
| `index.html` | Home page |
| `real-estate.html` | Real estate advisory |
| `ai.html` | AI advisory and Responsible AI |
| `digital-transformation.html` | Digital and data transformation (data modernisation, data governance) |
| `risk-advisory.html` | Risk advisory |
| `assets/css/styles.css` | All styling. Brand colours are the variables at the top (`--navy`, `--blue`, `--cerulean`) |
| `assets/img/` | Logo files (SVG), favicon, app icons and the image shown when the site is shared |
| `assets/js/site.js` | **Settings** (email, phone, address, form), header menu, footer and contact form shared by every page |
| `assets/js/real-estate.js`, `ai.js`, `digital.js`, `risk.js` | The wording inside each page's interactive panels |
| `robots.txt`, `sitemap.xml` | For search engines (already set to foxberryconsulting.com) |

## 1. Preview on your computer

Double-click `index.html`. Everything works offline except the fonts (they load from Google Fonts and fall back to Georgia and Arial).

## 2. How to edit

**A. Change text on a page (easiest, no code).**
Open any page with `?edit` on the end of its address, for example `index.html?edit` on your computer or `https://www.foxberryconsulting.com/ai.html?edit` once live. Click any heading, paragraph, list item or button label and type. Press **Download this page**, then replace the matching file in your site folder with the downloaded one and upload it again.
This edits the page text only. Nothing is saved to the server by itself, and visitors who add `?edit` cannot change your live site.

**B. Change contact details, menu and footer.**
Open `assets/js/site.js`. The block at the top (`window.FOX = {...}`) holds your email, phone, address, LinkedIn link and form settings. The header menu and footer are further down in the same file. One change updates all five pages.

**C. Change the wording in interactive panels.**
The wheels, tabs, heat map, maturity ladder, readiness questions and the property strategy panels read their text from clearly labelled blocks at the top of each page script (`// ---------- EDIT: ... ----------`). Change the text inside the quotation marks and keep the commas and brackets.

**D. Change colours.**
Open `assets/css/styles.css` and edit the variables in `:root` near the top.

**E. Edit the HTML directly.**
Each page is plain HTML with comments such as `<!-- ===== OVERVIEW ===== -->`. Every `<section>` can be edited, moved or deleted in any text editor (VS Code, Notepad++, TextEdit in plain-text mode).

## 3. Things to replace before you launch

- Leadership names and biographies (home page, "Our people": `[Founder name]`, `[Partner name]`)
- Office address and phone number (`site.js` settings)
- LinkedIn link (`site.js` settings)
- Privacy and Terms pages (the footer links currently point to `#`)
- Confirm the email address `hello@foxberryconsulting.com` exists
- Review the claims on the site that only you can vouch for, for example "100% senior-led" (home page) and "independent of software and model vendors" (AI page FAQ)
- The "Our point of view" cards on the home page are short statements of your view, not articles. Replace them with real articles as you publish
- The yield check and AI readiness check are indicative tools. Keep the "indicative only" wording

## 4. How to put it online

Any of these work, and all have free plans. Upload the **contents** of this folder so that `index.html` sits at the top level.

1. **Netlify Drop** (quickest): go to app.netlify.com/drop and drag the folder onto the page. You get a live link in seconds. Then add your domain under *Domain management*.
2. **Cloudflare Pages**: create a Pages project, choose *Direct upload*, and upload the folder.
3. **GitHub Pages**: put the files in a GitHub repository, then enable Pages in the repository settings.
4. **Your existing web host** (cPanel, GoDaddy, Hostinger and similar): upload the files with the file manager or FTP into the `public_html` folder.

**Connecting foxberryconsulting.com:** at your domain registrar, follow your host's instructions to point the domain to it (usually a CNAME or A record, and the host shows you the exact values). Make sure both `foxberryconsulting.com` and `www.foxberryconsulting.com` work, and turn on the free HTTPS certificate.

## 5. Making the contact form deliver to you

By default the form opens the visitor's email app with their message filled in. To receive submissions directly:

1. Create a free form at formspree.io and copy its address (it looks like `https://formspree.io/f/abcdwxyz`).
2. Paste it into `formEndpoint` in the settings block of `assets/js/site.js`.
3. Upload the file again.

## 6. Adding another page (for example M&A advisory)

1. Make a copy of `risk-advisory.html` and rename it, for example `ma-advisory.html`.
2. Change the `<title>`, description, headings and text. Keep `<div id="site-header">`, `<div id="site-contact">`, `<div id="site-footer">` and the `<script src="assets/js/site.js">` line.
3. Delete the `<script src="assets/js/risk.js">` line and any sections that rely on it, or copy and adapt that script.
4. Add a link to the new page in the menu in `assets/js/site.js` and in `sitemap.xml`.

## 7. Logo

The final logo is in `assets/img/`: `logo-horizontal-color.svg` (header), `logo-horizontal-reverse.svg` (footer and dark mode), plus stacked and mark-only versions, the favicon and `og-image.png` (the preview image when the site is shared on LinkedIn, WhatsApp and similar). To change the logo later, replace these files keeping the same names. The full logo kit (one-colour versions, PNGs, usage notes) is supplied separately.

## Good to know

- The header, footer and contact form are inserted by JavaScript so you only have to edit them once. The main content of every page is plain HTML that search engines can read directly.
- The site uses no images that need uploading. Illustrations are built into the pages as SVG. Add photographs by placing files in `assets/img/` and using normal `<img>` tags.
- Text editing via `?edit` works in current versions of Chrome, Edge, Safari and Firefox.
